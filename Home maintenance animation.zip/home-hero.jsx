/* Home maintenance hero animation — scenes for SceneStage */
const { SceneStage, useScene, clamp, useTweaks, TweaksPanel, TweakSection, TweakText, TweakToggle } = window;

const C = {
  paper: '#FFFFFF', ink: '#161616', accent: '#D01F1F', teal: '#8A1414',
  roof: '#1E1E1E', wall: '#F7F3F1', warm: '#FFC978', door: '#B01818',
  muted: '#6E6862', ground: '#EAE4E1', green: '#1E1E1E', red: '#D01F1F',
};
const FONT = "'Outfit', sans-serif";
let TW = {}; // current tweaks, set by App each render

const eo = x => 1 - Math.pow(1 - x, 3);
const eio = x => x < .5 ? 4*x*x*x : 1 - Math.pow(-2*x + 2, 3) / 2;
const back = x => 1 + 2.70158 * Math.pow(x - 1, 3) + 1.70158 * Math.pow(x - 1, 2);
const seg = (t, t0, d, ez) => { const x = clamp((t - t0) / d, 0, 1); return ez ? ez(x) : x; };

/* ---------- shared parts ---------- */
function House({ size = 1, lit = false, glow = 0 }) {
  const u = size;
  return (
    <div style={{ position: 'relative', width: 420*u, height: 360*u }}>
      <div style={{ position: 'absolute', left: 300*u, top: 24*u, width: 36*u, height: 96*u, background: '#3A3A3A' }} />
      <div style={{ position: 'absolute', left: 0, top: 0, width: 0, height: 0,
        borderLeft: `${210*u}px solid transparent`, borderRight: `${210*u}px solid transparent`,
        borderBottom: `${124*u}px solid ${C.roof}` }} />
      <div style={{ position: 'absolute', left: 30*u, top: 122*u, width: 360*u, height: 238*u, background: C.wall,
        boxShadow: glow ? `0 0 ${80*glow}px rgba(255,195,100,${0.55*glow})` : 'none' }} />
      <div style={{ position: 'absolute', left: 180*u, top: 232*u, width: 60*u, height: 128*u, background: C.door,
        borderRadius: `${8*u}px ${8*u}px 0 0` }} />
      {[76, 284].map(x => (
        <div key={x} style={{ position: 'absolute', left: x*u, top: 164*u, width: 60*u, height: 60*u,
          background: lit ? C.warm : '#A7BCC4', border: `${6*u}px solid ${C.roof}`, boxSizing: 'content-box' }} />
      ))}
    </div>
  );
}

const Check = ({ show }) => {
  const s = 84, k = clamp(show, 0, 1), sc = back(k);
  return (
    <div style={{ width: s, height: s, borderRadius: '50%', background: C.green, position: 'relative',
      transform: `scale(${sc})`, opacity: Math.min(1, k*3), boxShadow: '0 10px 24px rgba(76,138,95,.35)' }}>
      <div style={{ position: 'absolute', left: s*.2, top: s*.5, width: s*.26, height: s*.11, background: '#fff', transform: 'rotate(45deg)', borderRadius: s }} />
      <div style={{ position: 'absolute', left: s*.3, top: s*.42, width: s*.46, height: s*.11, background: '#fff', transform: 'rotate(-45deg)', borderRadius: s }} />
    </div>
  );
};

const Alert = ({ show }) => {
  const k = clamp(show, 0, 1);
  return (
    <div style={{ width: 56, height: 56, borderRadius: '50%', background: C.red, color: '#fff',
      display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: FONT,
      fontWeight: 800, fontSize: 32, transform: `scale(${back(k)})`, opacity: Math.min(1, k*3),
      boxShadow: '0 8px 20px rgba(196,84,59,.4)' }}>!</div>
  );
};

const Label = ({ children, style }) => (
  <div style={{ fontFamily: FONT, fontWeight: 600, fontSize: 30, color: C.muted, letterSpacing: '.02em', ...style }}>{children}</div>
);

/* ---------- Scene 1: Opening ---------- */
function Opening() {
  const { localTime: lt, progress: p } = useScene();
  const sunY = 620 - 300 * eio(p);
  const t1 = seg(lt, 1.1, 1.1, eo), t2 = seg(lt, 2.1, 1.1, eo);
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden',
      background: 'linear-gradient(#F7DBD6 0%, #FBEFEC 55%, #FFFFFF 100%)' }}>
      <div style={{ position: 'absolute', left: 1120, top: sunY, width: 160, height: 160, borderRadius: '50%',
        background: '#D01F1F', boxShadow: '0 0 120px 40px rgba(208,31,31,.35)' }} />
      {[[140, 150, 0], [980, 90, 1]].map(([x, y, i]) => (
        <div key={i} style={{ position: 'absolute', left: x + (i ? -90 : 110) * p, top: y, width: 260, height: 56,
          borderRadius: 60, background: 'rgba(255,255,255,.75)' }} />
      ))}
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: 170, background: C.ground }} />
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 130, display: 'flex', justifyContent: 'center',
        transform: `scale(${1 + 0.05 * p})`, transformOrigin: '50% 100%' }}>
        <House />
      </div>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 120, textAlign: 'center' }}>
        <div style={{ fontFamily: FONT, fontWeight: 800, fontSize: 92, color: C.ink, letterSpacing: '-0.02em',
          opacity: t1, transform: `translateY(${24 * (1 - t1)}px)` }}>{TW.tagline}</div>
        <div style={{ fontFamily: FONT, fontWeight: 500, fontSize: 34, color: C.muted, marginTop: 18,
          opacity: t2, transform: `translateY(${18 * (1 - t2)}px)` }}>Repairs & maintenance by {TW.brandName}</div>
      </div>
    </div>
  );
}

/* ---------- Scene 2: Problems ---------- */
function Card({ x, y, show, children, label, alertAt }) {
  const k = clamp(show, 0, 1);
  return (
    <div style={{ position: 'absolute', left: x, top: y, width: 380, height: 360, background: '#fff',
      borderRadius: 24, boxShadow: '0 18px 40px rgba(42,38,32,.12)', opacity: Math.min(1, k*2.5),
      transform: `translateY(${34 * (1 - eo(k))}px) scale(${0.92 + 0.08 * back(k)})`,
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'flex-end', paddingBottom: 28 }}>
      {children}
      <Label style={{ marginTop: 20 }}>{label}</Label>
      <div style={{ position: 'absolute', top: -18, right: -14 }}><Alert show={alertAt} /></div>
    </div>
  );
}
function Faucet({ lt, dripping = true }) {
  return (
    <div style={{ position: 'relative', width: 220, height: 200 }}>
      <div style={{ position: 'absolute', left: 0, top: 30, width: 170, height: 34, background: '#9AA6AD', borderRadius: 8 }} />
      <div style={{ position: 'absolute', left: 140, top: 30, width: 34, height: 90, background: '#9AA6AD', borderRadius: 8 }} />
      <div style={{ position: 'absolute', left: 60, top: 0, width: 46, height: 46, borderRadius: '50%', background: '#7C8A92' }} />
      {dripping && [0, 1, 2].map(i => {
        const y = (lt * 130 + i * 55) % 160;
        return <div key={i} style={{ position: 'absolute', left: 149, top: 120 + y * 0.5, width: 16, height: 22,
          borderRadius: '50% 50% 60% 60%', background: '#6FA8C9', opacity: 1 - y / 190 }} />;
      })}
    </div>
  );
}
function Bulb({ on, glow = 0 }) {
  return (
    <div style={{ position: 'relative', width: 160, height: 200 }}>
      <div style={{ position: 'absolute', left: 20, top: 0, width: 120, height: 120, borderRadius: '50%',
        background: on > .5 ? C.warm : '#D8D2C4', opacity: 0.45 + 0.55 * on,
        boxShadow: glow ? `0 0 ${70*glow}px ${20*glow}px rgba(255,201,120,.55)` : 'none' }} />
      <div style={{ position: 'absolute', left: 55, top: 118, width: 50, height: 44, background: '#8B8578', borderRadius: '0 0 10px 10px' }} />
    </div>
  );
}
function Problems() {
  const { localTime: lt, dur } = useScene();
  const flick = (Math.sin(lt * 11) + Math.sin(lt * 17)) > 0 ? 1 : 0.15;
  const s1 = seg(lt, 0.6, 0.8), s2 = seg(lt, 1.5, 0.8), s3 = seg(lt, 2.4, 0.8);
  return (
    <div style={{ position: 'absolute', inset: 0, background: '#F6F1EF', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: 120, background: '#DBD3CF' }} />
      <div style={{ position: 'absolute', left: 0, right: 0, top: 86, textAlign: 'center', fontFamily: FONT,
        fontWeight: 800, fontSize: 64, color: C.ink, letterSpacing: '-0.01em' }}>Little problems add up.</div>
      <Card x={130} y={300} show={s1} label="Leaky faucet" alertAt={seg(lt, 1.3, 0.5)}>
        <Faucet lt={lt} />
      </Card>
      <Card x={610} y={300} show={s2} label="Flickering lights" alertAt={seg(lt, 2.2, 0.5)}>
        <Bulb on={flick} />
      </Card>
      <Card x={1090} y={300} show={s3} label="Cracks & wear" alertAt={seg(lt, 3.1, 0.5)}>
        <div style={{ position: 'relative', width: 200, height: 200 }}>
          <div style={{ position: 'absolute', left: 20, top: 10, width: 160, height: 180, background: '#EDE4D2', borderRadius: 10 }} />
          <div style={{ position: 'absolute', left: 95, top: 26, width: 8, height: 62, background: '#8B8578', transform: 'rotate(18deg)' }} />
          <div style={{ position: 'absolute', left: 108, top: 78, width: 8, height: 58, background: '#8B8578', transform: 'rotate(-22deg)' }} />
          <div style={{ position: 'absolute', left: 96, top: 128, width: 8, height: 54, background: '#8B8578', transform: 'rotate(14deg)' }} />
        </div>
      </Card>
    </div>
  );
}

/* ---------- Scene 3: On the way ---------- */
function Van({ x, bounce }) {
  return (
    <div style={{ position: 'absolute', left: x, bottom: 128, width: 460, height: 200, transform: `translateY(${bounce}px)` }}>
      <div style={{ position: 'absolute', left: 0, top: 30, width: 340, height: 130, background: C.accent, borderRadius: '14px 6px 6px 14px' }} />
      <div style={{ position: 'absolute', left: 340, top: 66, width: 100, height: 94, background: C.accent, borderRadius: '0 16px 4px 0' }} />
      <div style={{ position: 'absolute', left: 356, top: 78, width: 60, height: 42, background: '#BFD4DC', borderRadius: '0 10px 0 0' }} />
      <div style={{ position: 'absolute', left: 26, top: 68, fontFamily: FONT, fontWeight: 800, fontSize: 40, color: '#fff', letterSpacing: '.01em' }}>{TW.brandName}</div>
      {[70, 330].map(wx => (
        <div key={wx} style={{ position: 'absolute', left: wx, top: 140, width: 60, height: 60, borderRadius: '50%',
          background: C.ink, border: '10px solid #4A453C', boxSizing: 'border-box' }} />
      ))}
    </div>
  );
}
function OnTheWay() {
  const { localTime: lt, dur } = useScene();
  const drive = seg(lt, 0.2, dur * 0.5, eo);
  const x = -480 + 1000 * drive;
  const bounce = Math.sin(lt * 22) * 3 * (1 - drive);
  const t1 = seg(lt, dur * 0.58, 1, eo);
  return (
    <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(#F5EBE9, #FFFFFF 70%)', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: 150, background: '#242424' }} />
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 74, height: 6,
        background: 'repeating-linear-gradient(90deg, #FFFFFF 0 70px, transparent 70px 140px)' }} />
      <div style={{ position: 'absolute', right: 90, bottom: 150 }}><House size={0.7} /></div>
      <Van x={x} bounce={bounce} />
      <div style={{ position: 'absolute', left: 0, right: 0, top: 130, textAlign: 'center', fontFamily: FONT,
        fontWeight: 800, fontSize: 76, color: C.ink, opacity: t1, transform: `translateY(${24 * (1 - t1)}px)` }}>
        Help is on the way.
      </div>
      <div style={{ position: 'absolute', left: 0, right: 0, top: 232, textAlign: 'center', fontFamily: FONT,
        fontWeight: 500, fontSize: 32, color: C.muted, opacity: seg(lt, dur * 0.68, 1, eo) }}>
        Same-week visits, on-time pros
      </div>
    </div>
  );
}

/* ---------- Scene 4: Fixes ---------- */
function FixPanel({ title, done, children }) {
  return (
    <div style={{ position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 36 }}>
      <div style={{ transform: 'scale(1.5)', height: 300, display: 'flex', alignItems: 'center' }}>{children}</div>
      <div style={{ fontFamily: FONT, fontWeight: 800, fontSize: 58, color: C.ink }}>{title}</div>
      <Check show={done} />
    </div>
  );
}
function Fixes() {
  const { localTime: lt, dur } = useScene();
  const third = dur / 3;
  const k = Math.min(2, Math.floor(lt / third));
  const u = clamp((lt - k * third) / third, 0, 1);
  const done = seg(u, 0.58, 0.22);
  const bgs = ['#F6F1EF', '#FBEAE7', '#F2F2F2'];
  return (
    <div style={{ position: 'absolute', inset: 0, background: bgs[k], overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: 70, left: 0, right: 0, textAlign: 'center', fontFamily: FONT,
        fontWeight: 600, fontSize: 32, color: C.muted, letterSpacing: '.14em' }}>ONE VISIT · {['FIX 1 OF 3', 'FIX 2 OF 3', 'FIX 3 OF 3'][k]}</div>
      {k === 0 && (
        <FixPanel title="Leak — fixed" done={done}>
          <div style={{ position: 'relative' }}>
            <Faucet lt={lt} dripping={u < 0.42} />
            <div style={{ position: 'absolute', left: 46, top: -14, width: 74, height: 74, borderRadius: '50%',
              border: '10px solid #5A6B74', boxSizing: 'border-box', transform: `rotate(${90 * seg(u, 0.25, 0.2, eio)}deg)` }}>
              <div style={{ position: 'absolute', left: 22, top: -18, width: 10, height: 22, background: '#5A6B74' }} />
            </div>
          </div>
        </FixPanel>
      )}
      {k === 1 && (
        <FixPanel title="Wiring — steady" done={done}>
          <Bulb on={u < 0.38 ? ((Math.sin(lt * 13) > 0) ? 1 : 0.2) : 1} glow={seg(u, 0.38, 0.25)} />
        </FixPanel>
      )}
      {k === 2 && (
        <FixPanel title="Walls — refreshed" done={done}>
          <div style={{ position: 'relative', width: 300, height: 200, background: '#E4DAC6', borderRadius: 10, overflow: 'hidden' }}>
            <div style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: `${100 * seg(u, 0.08, 0.45, eio)}%`, background: C.teal }} />
            <div style={{ position: 'absolute', left: `${100 * seg(u, 0.08, 0.45, eio)}%`, top: 8, width: 26, height: 120,
              marginLeft: -13, background: '#F1B45C', borderRadius: 8, border: '4px solid #8B8578', boxSizing: 'border-box' }} />
          </div>
        </FixPanel>
      )}
    </div>
  );
}

/* ---------- Scene 5: Services ---------- */
const SERVICES = [
  ['Plumbing', '#D01F1F'], ['Electrical', '#161616'], ['HVAC', '#E4574A'],
  ['Painting', '#8A1414'], ['Carpentry', '#4A4A4A'], ['Roofing & gutters', '#B01818'],
];
function Services() {
  const { localTime: lt, dur } = useScene();
  const t1 = seg(lt, 0.2, 0.9, eo);
  return (
    <div style={{ position: 'absolute', inset: 0, background: C.paper, display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center', gap: 60, overflow: 'hidden' }}>
      <div style={{ fontFamily: FONT, fontWeight: 800, fontSize: 84, color: C.ink, letterSpacing: '-0.02em',
        opacity: t1, transform: `translateY(${20 * (1 - t1)}px)` }}>One call. Every fix.</div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 380px)', gap: 28 }}>
        {SERVICES.map(([name, col], i) => {
          const k = seg(lt, 1.1 + i * 0.28, 0.55);
          return (
            <div key={name} style={{ display: 'flex', alignItems: 'center', gap: 20, background: '#fff',
              borderRadius: 18, padding: '26px 30px', boxShadow: '0 12px 28px rgba(22,22,22,.1)', border: '1px solid #F0E8E6',
              opacity: Math.min(1, k*2.5), transform: `scale(${0.9 + 0.1 * back(k)})` }}>
              <div style={{ width: 30, height: 30, borderRadius: 8, background: col, flex: 'none' }} />
              <div style={{ fontFamily: FONT, fontWeight: 600, fontSize: 32, color: C.ink }}>{name}</div>
            </div>
          );
        })}
      </div>
      <div style={{ fontFamily: FONT, fontWeight: 500, fontSize: 30, color: C.muted,
        opacity: seg(lt, dur * 0.62, 0.9, eo) }}>Licensed, insured & background-checked pros</div>
    </div>
  );
}

/* ---------- Scene 6: Finale ---------- */
function Finale() {
  const { localTime: lt, progress: p, dur } = useScene();
  const glow = seg(lt, 0.4, 1.2, eo);
  const t1 = seg(lt, 0.8, 1, eo), t2 = seg(lt, 1.5, 1, eo);
  const amp = Math.min(1, p * 6, (1 - p) * 6);
  const pulse = 1 + 0.025 * Math.sin(lt * 4) * amp;
  return (
    <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(#121212 0%, #2A1A18 55%, #5E1414 100%)', overflow: 'hidden' }}>
      {[[210, 120], [430, 210], [1240, 90], [1440, 190], [860, 70]].map(([x, y], i) => (
        <div key={i} style={{ position: 'absolute', left: x, top: y, width: 6, height: 6, borderRadius: '50%',
          background: '#fff', opacity: 0.4 + 0.5 * Math.abs(Math.sin(lt * 2 + i)) }} />
      ))}
      <div style={{ position: 'absolute', right: 180, top: 90, width: 90, height: 90, borderRadius: '50%', background: '#F2EAE8' }} />
      <div style={{ position: 'absolute', left: 0, right: 0, bottom: 0, height: 150, background: '#0D0D0D' }} />
      <div style={{ position: 'absolute', left: 150, bottom: 130 }}>
        <House size={0.95} lit={glow > 0.3} glow={glow} />
      </div>
      <div style={{ position: 'absolute', right: 140, top: 240, width: 640, textAlign: 'left' }}>
        <div style={{ fontFamily: FONT, fontWeight: 800, fontSize: 90, color: '#FFFFFF', letterSpacing: '-0.02em',
          opacity: t1, transform: `translateY(${24 * (1 - t1)}px)` }}>{TW.brandName}</div>
        <div style={{ fontFamily: FONT, fontWeight: 500, fontSize: 36, color: '#E8B7B0', marginTop: 12,
          opacity: t1 }}>{TW.tagline}</div>
        <div style={{ display: 'inline-flex', alignItems: 'center', gap: 16, marginTop: 48, background: C.accent,
          color: '#fff', fontFamily: FONT, fontWeight: 700, fontSize: 36, padding: '24px 44px', borderRadius: 60,
          opacity: t2, transform: `scale(${pulse * (0.9 + 0.1 * back(t2))})`, boxShadow: '0 16px 40px rgba(208,31,31,.4)' }}>
          {TW.cta}
        </div>
        <div style={{ fontFamily: FONT, fontWeight: 500, fontSize: 30, color: '#C9BAB6', marginTop: 26, opacity: t2 }}>{TW.ctaUrl}</div>
      </div>
    </div>
  );
}

/* ---------- App ---------- */
function HomeHero() {
  const [t, setTweak] = useTweaks(window.TWEAK_DEFAULTS);
  TW = t;
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%' }}>
      <SceneStage width={1600} height={900} bg={C.paper} scenes={window.OM_SCENES} playback={window.OM_PLAYBACK}>
        {{ Opening, Problems, OnTheWay, Fixes, Services, Finale }}
      </SceneStage>
      <TweaksPanel>
        <TweakSection label="Brand" />
        <TweakText label="Name" value={t.brandName} onChange={v => setTweak('brandName', v)} />
        <TweakText label="Tagline" value={t.tagline} onChange={v => setTweak('tagline', v)} />
        <TweakText label="CTA button" value={t.cta} onChange={v => setTweak('cta', v)} />
        <TweakText label="Website" value={t.ctaUrl} onChange={v => setTweak('ctaUrl', v)} />
        <TweakSection label="Editor" />
        <TweakToggle label="Motion editor" value={t.motionEditor} onChange={v => setTweak('motionEditor', v)} />
      </TweaksPanel>
    </div>
  );
}
window.HomeHero = HomeHero;
